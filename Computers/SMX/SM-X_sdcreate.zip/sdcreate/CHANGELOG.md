15/01/2020 - Modified 'sdcreate' to generate cards with SofaRun 7.0, complete DOSTOOLS, cleanup on system's directory and fixed an error when generating the directory MM when using Windows's script;
